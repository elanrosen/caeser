# HillersHollow
## Text Adventure Game and Lesson Plan for Intro to CS class

For a high school Intro to Computer Science class I teach, I plan an intro to Python unit around text adventures and interactive fiction. Students begin with a crash course in Python syntax, how to write and run simple programs, and then progress to using arithmetic and logical operators.

Once students have established a comfort level with beginner Python programming, I introduce functions and why they are a necessary abstraction in code. We then explore the history of text-based adventure games (Colossal Cave Adventure is a great one to introduce them to), and discuss how students can create their own text-based adventures using Python code.

HillersHollow is a brief text-adventure I wrote to do some modeling for students. After having them play mine, I give them a template to get themselves started and we go from there!

If you have your own text-adventure units you use in your CS classes, I would love to hear more about them!
